java -jar jar/hooverbot.jar

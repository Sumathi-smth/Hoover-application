import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.hoover.exception.HooverException;
import com.hoover.main.HooverMain;
import com.hoover.main.Output;
import com.hoover.model.Position;
import com.hoover.parsers.HooverParser;
import org.junit.Assert;
import org.junit.Test;

import java.awt.*;
import java.net.URISyntaxException;

public class TestHooverMain {
    
    @Test
    public void validData() throws URISyntaxException, JsonProcessingException {
        String filePath = TestUtils.getFilePath("data/input2.txt");
        HooverMain main = new HooverMain(filePath);
        main.run();
        Output output = main.getOutput();
        Assert.assertNotNull(output);
        Output expectedOutput = new Output(new Position(new Point(0,3),null), 2);
        Assert.assertEquals(expectedOutput.getPosition(), output.getPosition());
        Assert.assertEquals(expectedOutput.getDirtsCleaned(), output.getDirtsCleaned());
    }

    @Test
    public void invalidRoomDimension() throws URISyntaxException, JsonProcessingException {
        String filePath = TestUtils.getFilePath("data/invalidRoomDimension.txt");
        HooverMain main = new HooverMain(filePath);
        main.run();
    }

    @Test
    public void roomDimensionWithAlphabet() throws URISyntaxException, JsonProcessingException {
        String filePath = TestUtils.getFilePath("data/roomDimensionWithAlphabet.txt");
        HooverMain main = new HooverMain(filePath);
        main.run();
    }
}

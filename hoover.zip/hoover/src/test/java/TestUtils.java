import java.io.File;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;

public class TestUtils {

    public static File getResourceFile(String s) throws URISyntaxException {
        URL res = TestUtils.class.getClassLoader().getResource(s);
        assert res != null;
        return Paths.get(res.toURI()).toFile();
    }

    public static String getFilePath(String s) throws URISyntaxException {
        URL res = TestUtils.class.getClassLoader().getResource(s);
        assert res != null;
        File file = Paths.get(res.toURI()).toFile();
        return file.getPath();
    }

}

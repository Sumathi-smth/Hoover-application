package com.hoover.model;

import com.hoover.validation.Validate;

import java.awt.*;

public class Position extends Point implements Validate {

    private RoomDimension dimension;

    public Position(Point p, RoomDimension dimension) {
        this(p.x, p.y, dimension);

    }

    public Position(int x, int y, RoomDimension dimension) {
        super(x, y);
        this.dimension = dimension;
    }

    public Position(Position position) {
        super(position);
    }

    @Override
    public boolean isValid() {
        if (dimension != null &&
                x >= 0 &&  x < dimension.x &&
                y >= 0 && y < dimension.y) {
            return true;
        }
        return false;
    }
}

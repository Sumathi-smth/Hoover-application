package com.hoover.model;

import com.hoover.validation.Validate;

import java.awt.*;

public class RoomDimension extends Point implements Validate {

    public RoomDimension(Point point) {
        super(point);
    }

    public RoomDimension(int x, int y) {
        super(x, y);
    }

    public RoomDimension(Integer x, Integer y) {
        super(x, y);
    }

    @Override
    public boolean isValid() {
        return x == y;
    }
}

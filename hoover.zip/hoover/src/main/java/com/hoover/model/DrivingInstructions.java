package com.hoover.model;

import com.hoover.exception.HooverException;
import com.hoover.validation.Validate;

import java.util.LinkedList;

public class DrivingInstructions implements Validate {
    LinkedList<Character> instructions = new LinkedList();

    public  DrivingInstructions(String instructionStr) throws HooverException {
        char[] instructionArray = instructionStr.toCharArray();

        for (char ch: instructionArray ) {
            if(!checkInstruction(ch)) {
                throw new HooverException("Driving Instruction contains invalid Direction");
            }
            instructions.add(ch);
        }
    }

    private boolean checkInstruction(char ch) {
        switch (ch) {
            case 'N' :
            case 'S' :
            case 'E' :
            case 'W' :
                return true;
            default:
                return false;
        }
    }

    public LinkedList<Character> getInstructions() {
        return instructions;
    }

    public void setInstructions(LinkedList<Character> instructions) {
        this.instructions = instructions;
    }

    @Override
    public boolean isValid() {
        return false;
    }


}

package com.hoover.parsers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hoover.exception.HooverException;
import com.hoover.utils.MyLogger;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;

public class JsonParser {

    public HooverParser parse(String filepath) throws  HooverException {

        //read the input file to hoover object
        File file = null;
        if(filepath == null) {
            throw new HooverException("Invalid file path");
        } else {
            file = new File(filepath);
            if (file == null || !file.exists() || !file.isFile()) {
                throw new HooverException("Input file is not found");
            }
        }


        //map the json obect to
        ObjectMapper mapper = new ObjectMapper();
        MyLogger.LOGGER.log(Level.INFO, "Parsing JSON string to HooverParser");
        try {
            HooverParser hooverParser  = mapper.readValue(file, HooverParser.class);
            MyLogger.LOGGER.log(Level.INFO, "Parsed to HooverParser object....\n" + hooverParser);
            return hooverParser;
        } catch (IOException e) {
            throw new HooverException("Unable to parse the input file", e);
        }
    }
}

package com.hoover.main;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.hoover.exception.HooverException;
import com.hoover.parsers.HooverParser;
import com.hoover.parsers.JsonParser;
import com.hoover.utils.MyLogger;

import java.io.File;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.file.Paths;
import java.util.logging.Level;

/**
 * This is the main class to run the Hoover application
 */
public class HooverMain {
   public static String DEFAULT_FILE = "data/input.txt";

    private String filePath = "";

    private Output output = null;

    public HooverMain(String filePath) {
        this.filePath = filePath;
    }

    public static void main(String[] args) throws JsonProcessingException, URISyntaxException {
        HooverMain hooverDemo = null;
        if (args.length > 0) {
            MyLogger.LOGGER.log(Level.INFO, "main method contains an argument for path - \n" + args[0]);
            hooverDemo = new HooverMain(args[0]);
        } else {
            URL res = HooverMain.class.getClassLoader().getResource(DEFAULT_FILE);
            assert res != null;
            File file = Paths.get(res.toURI()).toFile();
            hooverDemo = new HooverMain(file.getPath());
        }
        hooverDemo.run();
    }

    /**
     * Validates the input file and parsers the json file to java bean object. Then starts hoovering based on the coords
     * and Instruction specified.
     *
     * @throws JsonProcessingException
     */
    public void run() throws JsonProcessingException {
        boolean isValid = true;

        //Parse json file to HooverParser object
        JsonParser jsonParser = new JsonParser();
        HooverParser hooverParser = null;
        try {
            hooverParser = jsonParser.parse(filePath);
        } catch (HooverException e) {
            isValid = false;
            MyLogger.LOGGER.log(Level.SEVERE, "Unable to parse the json file" + e.getCause());
        }

        //validate the parsed hoover object
        isValid = isValid ? validate(hooverParser) : false;

        //get the coords and sets the patches before hoovering
        if (isValid) {
            Hoovering hoover = new Hoovering(hooverParser.getPatches(), hooverParser.getCoords());
            output = hoover.clean(hooverParser.getInstructions());

            if (output != null) {
                MyLogger.LOGGER.log(Level.INFO, "Successfully cleaned the Position ");
              /*  ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
                String json = ow.writeValueAsString(output);
                System.out.println(json);*/
                MyLogger.LOGGER.log(Level.INFO, output.toString());
            }
        }
    }

    private boolean validate(HooverParser hooverParser) {
        if (!hooverParser.getRoomSize().isValid()) {
            MyLogger.LOGGER.log(Level.SEVERE, "Invalid room size");
            return false;
        } else if (!hooverParser.getCoords().isValid()) {
            MyLogger.LOGGER.log(Level.SEVERE, "Invalid coords");
            return false;
        } else if (!hooverParser.getPatches().isValid()) {
            MyLogger.LOGGER.log(Level.SEVERE, "Invalid patches");
            return false;
        }

        return true;
    }

    public Output getOutput() {
        return output;
    }
}

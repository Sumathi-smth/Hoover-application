package com.hoover.main;

import com.hoover.model.Position;

/**
 * Output of the hoovering to display the end coords and the dirts cleaned.
 */
public class Output {

    private Position position;
    private int dirtsCleaned;

    public Output(Position position, int dirtsCleaned) {
        this.position = position;
        this.dirtsCleaned = dirtsCleaned;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public int getDirtsCleaned() {
        return dirtsCleaned;
    }

    public void setDirtsCleaned(int dirtsCleaned) {
        this.dirtsCleaned = dirtsCleaned;
    }

    @Override
    public String toString() {
        return "\n{\n\t" + "\"coords\" : [" + position.x + "," + position.y + "], \n\t" +
                "\"patches\" : " + dirtsCleaned + "\n}";
    }
}

package com.hoover.main;

import com.hoover.model.DrivingInstructions;
import com.hoover.model.Patch;
import com.hoover.model.Position;

import java.util.List;

/**
 * This Class is moves the hoover based on the position and cleans if it contains a dirt. Once it reaches the last
 * instruction it sets the output result.
 */
public class Hoovering {

    private Patch patch;
    private Position position;
    private int dirtsCleaned = 0;
    Position previousPosition;


    public Hoovering(Patch patch, Position position) {
        this.patch = patch;
        this.position = position;
        previousPosition = new Position(position);
    }

    /**
     * move the hoover based on the direction - North, South, East or West. If it is any other character break
     * @param  direction
     */
    private void move(char direction) {
        previousPosition.setLocation(position);
        switch (direction) {
            case 'N':
                position.y++;
                break;
            case 'S':
                position.y--;
                break;
            case 'E':
                position.x++;
                break;
            case 'W':
                position.x--;
                break;
            default:
                break;
        }

        if(position.isValid()) {
            doClean(position);
        } else {
            position.setLocation(previousPosition);
        }
    }

    /**
     * traverse through the instruction list and move to the position based on it.
     * @param drivingInstructions drivingInstructions
     * @return Output
     */
    public Output clean(DrivingInstructions drivingInstructions) {

        Output output;

        if (position.isValid()) {
            doClean(position);
        }

        List<Character> instructionList = drivingInstructions.getInstructions();
        for (Character direction : instructionList) {
            move(direction);
        }

        output = new Output(position, dirtsCleaned);

        return output;
    }

    //checks if the specified position contains dirt
    private void doClean(Position position) {
        if (patch.containsDirt(position)) {
            dirtsCleaned++;
        }
    }
}

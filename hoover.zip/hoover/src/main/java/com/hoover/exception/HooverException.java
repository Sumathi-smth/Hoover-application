package com.hoover.exception;

public class HooverException extends Exception {

    public HooverException(String message) {
        super(message);
    }

    public HooverException(String message, int index) {
        super(message + " " + index);
    }

    public HooverException(String message, Exception e) {
        super(message, e);
    }

}
